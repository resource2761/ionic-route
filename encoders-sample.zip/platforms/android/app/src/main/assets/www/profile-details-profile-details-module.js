(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-details-profile-details-module"],{

/***/ "NX0N":
/*!***********************************************************!*\
  !*** ./src/app/profile-details/profile-details.module.ts ***!
  \***********************************************************/
/*! exports provided: ProfileDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfileDetailsPageModule", function() { return ProfileDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _profile_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./profile-details-routing.module */ "b7d+");
/* harmony import */ var _profile_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./profile-details.page */ "TqdS");







let ProfileDetailsPageModule = class ProfileDetailsPageModule {
};
ProfileDetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _profile_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProfileDetailsPageRoutingModule"]
        ],
        declarations: [_profile_details_page__WEBPACK_IMPORTED_MODULE_6__["ProfileDetailsPage"]]
    })
], ProfileDetailsPageModule);



/***/ }),

/***/ "TqdS":
/*!*********************************************************!*\
  !*** ./src/app/profile-details/profile-details.page.ts ***!
  \*********************************************************/
/*! exports provided: ProfileDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfileDetailsPage", function() { return ProfileDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_profile_details_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./profile-details.page.html */ "pB6M");
/* harmony import */ var _profile_details_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./profile-details.page.scss */ "Ydhi");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "a/9d");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");








let ProfileDetailsPage = class ProfileDetailsPage {
    constructor(camera, alertCtrl, modalCtrl, loadingctrl, actionsheetctrl, toastctrl, activatedroute, navctrl) {
        this.camera = camera;
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.loadingctrl = loadingctrl;
        this.actionsheetctrl = actionsheetctrl;
        this.toastctrl = toastctrl;
        this.activatedroute = activatedroute;
        this.navctrl = navctrl;
        this.store_image = "";
    }
    ngOnInit() {
        this.activatedroute.queryParams.subscribe(params => {
            this.fullname = params["fullname"];
            this.experience = params["experience"];
            this.category = params["category"];
            this.emailid = params["emailid"];
            this.phone = params["phone"];
            this.gender = params["gender"];
            this.state = params["state"];
            this.city = params["city"];
            this.pincode = params["pincode"];
            this.location = params["location"];
            this.address = params["address"];
            this.sub_category = params["sub_category"];
        });
    }
    /* select_media function take image from gallery and camera itself*/
    select_media() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionsheet = yield this.actionsheetctrl.create({
                header: 'Choose option',
                buttons: [
                    {
                        text: 'Select an image from Gallery',
                        handler: () => {
                            this.select_gallery_image();
                        }
                    },
                    {
                        text: 'Take a picture using Camera',
                        handler: () => {
                            this.open_camera();
                        }
                    },
                    {
                        text: 'Cancel',
                        role: 'cancel'
                    }
                ]
            });
            yield actionsheet.present();
        });
    }
    // select_gallery_image() to select an image as store photo from gallery
    select_gallery_image() {
        //console.log('Gallery selected')
        let options = {
            quality: 100,
            sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
            destinationType: this.camera.DestinationType.DATA_URL,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE,
            correctOrientation: true,
            targetHeight: 130,
            targetWidth: 160,
            allowEdit: true
        };
        this.camera.getPicture(options).then((base64image) => {
            console.log(base64image);
            this.store_image = "data:image/jpg;base64," + base64image;
        }).catch((error) => {
            const toast = this.toastctrl.create({
                message: 'Image Selection Error, Select a Valid Image',
                duration: 2000,
                buttons: [
                    {
                        text: 'Close',
                        handler: () => {
                            console.log('Close clicked');
                        }
                    }
                ]
            }).then((toastshow) => {
                toastshow.present();
            });
        });
    }
    // end of select_gallery_image() to select an image as store photo from gallery
    // open_camera() to take a picture as store photo 
    open_camera() {
        let options = {
            quality: 100,
            sourceType: this.camera.PictureSourceType.CAMERA,
            destinationType: this.camera.DestinationType.DATA_URL,
            //encodingType:this.camera.EncodingType.JPEG,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE,
            correctOrientation: true,
            targetHeight: 130,
            targetWidth: 160,
            allowEdit: true
        };
        this.camera.getPicture(options).then((base64image) => {
            console.log(base64image);
            this.store_image = "data:image/png;base64," + base64image;
        }).catch((error) => {
            const toast = this.toastctrl.create({
                message: 'Error in Camera, Required Valid Photo using Camera',
                duration: 2000,
                buttons: [
                    {
                        text: 'Close',
                        handler: () => {
                            console.log('Close clicked');
                        }
                    }
                ]
            }).then((toastshow) => {
                toastshow.present();
            });
            this.store_image = undefined;
        });
    }
};
ProfileDetailsPage.ctorParameters = () => [
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_4__["Camera"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ActionSheetController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] }
];
ProfileDetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-profile-details',
        template: _raw_loader_profile_details_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_profile_details_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ProfileDetailsPage);



/***/ }),

/***/ "Ydhi":
/*!***********************************************************!*\
  !*** ./src/app/profile-details/profile-details.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".camera_box {\n  border-radius: 0.5rem;\n  position: relative;\n  box-shadow: 2px 0px 10px #E7EAF0, 0.3;\n  height: 100px;\n  text-align: center;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  margin: 2rem 0rem;\n}\n.camera_box ion-icon {\n  color: #FCBC4B;\n  font-size: 2rem;\n  padding: 3rem 4rem;\n  border-radius: 1rem;\n  z-index: 0;\n  box-shadow: 0px 0px 10px rgba(212, 204, 204, 0.3);\n}\n.camera_box img {\n  width: 160px;\n  max-width: 160px;\n  height: 130px;\n  max-height: 130px;\n  position: absolute;\n  border-radius: 1rem;\n  z-index: -1;\n}\n.sample_text {\n  text-align: center;\n  padding-top: 20px;\n  font-size: 14pt;\n  color: #fbfbfb;\n}\n.profile-details {\n  text-align: left;\n  padding-top: 20px;\n  font-size: 18pt;\n  color: #337ca7;\n  margin-left: 20px;\n}\n.profile-head {\n  text-align: left;\n  padding-top: 5px;\n  font-size: 12pt;\n  color: #337ca7;\n  margin-left: 20px;\n}\n.profile-head-value {\n  text-align: left;\n  padding-top: 5px;\n  font-size: 12pt;\n  color: #337ca7;\n  margin-left: 20px;\n}\nion-toolbar {\n  --background: rgb(51, 124, 167);\n}\nion-toolbar ion-title {\n  --color:white;\n}\nion-toolbar ion-back-button {\n  --color:white;\n}\n.section1 {\n  background: #337ca7;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXHByb2ZpbGUtZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUNBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FBQUo7QUFFSTtFQUNJLGNBQUE7RUFDQSxlQUFBO0VBRUEsa0JBQUE7RUFDQSxtQkFBQTtFQUNBLFVBQUE7RUFFQSxpREFBQTtBQUZSO0FBUUk7RUFFSSxZQUFBO0VBQ0EsZ0JBQUE7RUFFQSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQVJSO0FBWUE7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFUSjtBQVlBO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFUSjtBQWFBO0VBQ0ksZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFWSjtBQWVBO0VBQ0ksZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFaSjtBQWdCQTtFQUVJLCtCQUFBO0FBZEo7QUFnQkk7RUFFSSxhQUFBO0FBZlI7QUFrQkk7RUFFSSxhQUFBO0FBakJSO0FBc0JBO0VBRUksbUJBQUE7QUFwQkoiLCJmaWxlIjoicHJvZmlsZS1kZXRhaWxzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYW1lcmFfYm94IHtcclxuICAgIC8vIGJhY2tncm91bmQ6ICNGRkZGRkY7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwLjUwcmVtO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYm94LXNoYWRvdzogMnB4IDBweCAxMHB4ICgjRTdFQUYwLCAwLjMpO1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBtYXJnaW46MnJlbSAwcmVtO1xyXG4gICAgXHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgICAgY29sb3I6ICNGQ0JDNEI7XHJcbiAgICAgICAgZm9udC1zaXplOiAycmVtO1xyXG4gICAgICAgIC8vYmFja2dyb3VuZDogI0ZGRkZGRjtcclxuICAgICAgICBwYWRkaW5nOiAzcmVtIDRyZW07XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMXJlbTtcclxuICAgICAgICB6LWluZGV4OiAwO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGJveC1zaGFkb3c6IDBweCAwcHggMTBweCByZ2JhKDIxMiwgMjA0LCAyMDQsIDAuMyk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgaW1nXHJcbiAgICB7XHJcbiAgICAgICAgd2lkdGg6IDE2MHB4O1xyXG4gICAgICAgIG1heC13aWR0aDogMTYwcHg7XHJcblxyXG4gICAgICAgIGhlaWdodDogMTMwcHg7XHJcbiAgICAgICAgbWF4LWhlaWdodDogMTMwcHg7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDFyZW07XHJcbiAgICAgICAgei1pbmRleDogLTE7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5zYW1wbGVfdGV4dCB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwYWRkaW5nLXRvcDogMjBweDtcclxuICAgIGZvbnQtc2l6ZTogMTRwdDtcclxuICAgIGNvbG9yOiByZ2IoMjUxLCAyNTEsIDI1MSk7XHJcbn1cclxuXHJcbi5wcm9maWxlLWRldGFpbHMge1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIHBhZGRpbmctdG9wOiAyMHB4O1xyXG4gICAgZm9udC1zaXplOiAxOHB0O1xyXG4gICAgY29sb3I6IHJnYig1MSwgMTI0LCAxNjcpO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbn1cclxuXHJcblxyXG4ucHJvZmlsZS1oZWFkIHtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBwYWRkaW5nLXRvcDogNXB4O1xyXG4gICAgZm9udC1zaXplOiAxMnB0O1xyXG4gICAgY29sb3I6IHJnYig1MSwgMTI0LCAxNjcpO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbn1cclxuXHJcblxyXG5cclxuLnByb2ZpbGUtaGVhZC12YWx1ZSB7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgcGFkZGluZy10b3A6IDVweDtcclxuICAgIGZvbnQtc2l6ZTogMTJwdDtcclxuICAgIGNvbG9yOiByZ2IoNTEsIDEyNCwgMTY3KTtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG59XHJcblxyXG5cclxuaW9uLXRvb2xiYXJcclxue1xyXG4gICAgLS1iYWNrZ3JvdW5kOiByZ2IoNTEsIDEyNCwgMTY3KTsgICBcclxuICAgIFxyXG4gICAgaW9uLXRpdGxlXHJcbiAgICB7XHJcbiAgICAgICAgLS1jb2xvcjp3aGl0ZTtcclxuICAgIH1cclxuXHJcbiAgICBpb24tYmFjay1idXR0b25cclxuICAgIHtcclxuICAgICAgICAtLWNvbG9yOndoaXRlO1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuLnNlY3Rpb24xXHJcbntcclxuICAgIGJhY2tncm91bmQ6IHJnYig1MSwgMTI0LCAxNjcpOyAgIFxyXG59Il19 */");

/***/ }),

/***/ "b7d+":
/*!*******************************************************************!*\
  !*** ./src/app/profile-details/profile-details-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: ProfileDetailsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfileDetailsPageRoutingModule", function() { return ProfileDetailsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _profile_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./profile-details.page */ "TqdS");




const routes = [
    {
        path: '',
        component: _profile_details_page__WEBPACK_IMPORTED_MODULE_3__["ProfileDetailsPage"]
    }
];
let ProfileDetailsPageRoutingModule = class ProfileDetailsPageRoutingModule {
};
ProfileDetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProfileDetailsPageRoutingModule);



/***/ }),

/***/ "pB6M":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/profile-details/profile-details.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Profile</ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"tabs/tab5\" [text]=\"buttonText\"></ion-back-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"section1\">\n    <ion-row>\n\n      <ion-col size=\"12\">\n        <div class=\"camera_box\">\n          <ion-icon name=\"camera\" (click)=\"select_media()\"></ion-icon>\n          <img src=\"{{this.store_image}}\" *ngIf=\"store_image\">\n\n        </div>\n      </ion-col>\n\n\n    </ion-row>\n\n\n    <ion-row>\n\n      <ion-col size=\"12\">\n        <div class=\"sample_text\">{{fullname}}</div>\n        <div class=\"sample_text\">{{category}}</div>\n        <div class=\"sample_text\">{{experience}}</div>\n\n      </ion-col>\n\n    </ion-row>\n  </div>\n\n  <ion-row>\n\n    <ion-col size=\"12\">\n      <div class=\"profile-details\">Profile Details</div>\n    </ion-col>\n\n  </ion-row>\n\n  <ion-row>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head\">Full Name</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head-value\">{{fullname}}</div>\n    </ion-col>\n\n\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head\">Email Id</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head-value\">{{emailid}}</div>\n    </ion-col>\n\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head\">Phone</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head-value\">{{phone}}</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head\">Gender</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head-value\">{{gender}}</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head\">State</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head-value\">{{state}}</div>\n    </ion-col>\n\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head\">City</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head-value\">{{city}}</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head\">Pincode</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head-value\">{{pincode}}</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head\">Location</div>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <div class=\"profile-head-value\">{{location}}</div>\n    </ion-col>\n\n\n    <ion-col size=\"6\">\n        <div class=\"profile-head\">Address</div>\n      </ion-col>\n  \n      <ion-col size=\"6\">\n        <div class=\"profile-head-value\">{{address}}</div>\n      </ion-col>\n\n      <ion-col size=\"6\">\n          <div class=\"profile-head\">Category</div>\n        </ion-col>\n    \n        <ion-col size=\"6\">\n          <div class=\"profile-head-value\">{{category}}</div>\n        </ion-col>\n\n\n        <ion-col size=\"6\">\n            <div class=\"profile-head\">Sub Category</div>\n          </ion-col>\n      \n          <ion-col size=\"6\">\n            <div class=\"profile-head-value\">{{sub_category}}</div>\n          </ion-col>\n  </ion-row>\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=profile-details-profile-details-module.js.map